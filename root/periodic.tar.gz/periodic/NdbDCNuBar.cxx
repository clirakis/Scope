#include "NdbDCNuBar.h"

ClassImp(NdbDCNuBar)
