#include "NdbParticle.h"

ClassImp(NdbParticle)
