#include "NdbThermalNeutron.h"

ClassImp(NdbThermalNeutron)

