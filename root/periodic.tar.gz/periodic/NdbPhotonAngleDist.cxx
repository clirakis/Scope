#include "NdbPhotonAngleDist.h"

ClassImp(NdbPhotonAngleDist)

