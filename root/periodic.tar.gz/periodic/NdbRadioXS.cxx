#include "NdbRadioXS.h"

ClassImp(NdbRadioXS)

