#include "NdbDCEnergyDist.h"

ClassImp(NdbDCEnergyDist)
