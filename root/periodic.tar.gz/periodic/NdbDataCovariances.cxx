#include "NdbDataCovariances.h"

ClassImp(NdbDataCovariances)
