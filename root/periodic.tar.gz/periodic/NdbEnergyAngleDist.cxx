#include "NdbEnergyAngleDist.h"

ClassImp(NdbEnergyAngleDist)
