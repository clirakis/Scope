#include "NdbDCRadioXS.h"

ClassImp(NdbDCRadioXS)
