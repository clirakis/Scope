#include "NdbFissionYield.h"

ClassImp(NdbFissionYield)

