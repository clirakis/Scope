#include "NdbResParam.h"

ClassImp(NdbResParam)

