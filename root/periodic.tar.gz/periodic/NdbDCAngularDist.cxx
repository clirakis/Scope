#include "NdbDCAngularDist.h"

ClassImp(NdbDCAngularDist)


