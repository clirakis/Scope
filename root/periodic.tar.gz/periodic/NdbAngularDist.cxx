
#include "NdbAngularDist.h"


ClassImp(NdbAngularDist)

