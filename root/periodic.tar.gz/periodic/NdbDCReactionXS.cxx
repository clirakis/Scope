#include "NdbDCReactionXS.h"

ClassImp(NdbDCReactionXS)
