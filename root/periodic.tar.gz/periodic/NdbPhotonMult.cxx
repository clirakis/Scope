#include "NdbPhotonMult.h"

ClassImp(NdbPhotonMult)

