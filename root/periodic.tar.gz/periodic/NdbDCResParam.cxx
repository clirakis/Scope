#include "NdbDCResParam.h"

ClassImp(NdbDCResParam)
