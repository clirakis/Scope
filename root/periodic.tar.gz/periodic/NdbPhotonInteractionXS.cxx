#include "NdbPhotonInteractionXS.h"

ClassImp(NdbPhotonInteractionXS)

