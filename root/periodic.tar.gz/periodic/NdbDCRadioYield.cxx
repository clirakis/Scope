#include "NdbDCRadioYield.h"

ClassImp(NdbDCRadioYield)
