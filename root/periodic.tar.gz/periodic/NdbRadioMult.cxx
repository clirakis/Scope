#include "NdbRadioMult.h"

ClassImp(NdbRadioMult)
