#include "NdbPhotonProdXS.h"

ClassImp(NdbPhotonProdXS)

