#include "NdbEnergyDist.h"

ClassImp(NdbEnergyDist)
