#include "NdbGeneralInfo.h"

ClassImp(NdbGeneralInfo)

