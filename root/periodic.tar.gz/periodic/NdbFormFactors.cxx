#include "NdbFormFactors.h"

ClassImp(NdbFormFactors)
