#include "NdbMT.h"

ClassImp(NdbMT);
