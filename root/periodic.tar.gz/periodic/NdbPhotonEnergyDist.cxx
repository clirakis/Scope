#include "NdbPhotonEnergyDist.h"

ClassImp(NdbPhotonEnergyDist)

