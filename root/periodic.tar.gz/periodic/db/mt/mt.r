/* process the mt description file */

"cat mt.org (stack"

nl = "0A"x
Count = 0

do while queued() > 0
	parse pull line
	if left(line,1)=="*" then iterate

	if pos('-',line)>0 then do
		say "Ooops found line=" line
	end;
	if datatype(line) == "NUM" then do
		mt = strip(line)
		parse pull short
		short = strip(short)
		parse pull desc
		do while queued()>0
			parse pull d
			if d<>"" & left(d,1) == " " then do
				desc = desc||nl||strip(d)
			end; else do
				comment = d
				leave
			end
		end
		do while queued()>0
			parse pull c
			if c<>"" then
				comment = comment||nl||strip(c)
			else
				leave
		end

		if pos('?',short)=0 then do
			Count = Count+1
			say mt short
			say desc
			say
			say comment
			say
		end

		old_mt = mt
		old_short = short
		old_desc = desc
		old_comment = comment
	end; else
	if word(line,1) = "..." then do
		parse var line "..." start stop

		do i=start to stop
			mt = old_mt + i-start
			short = changestr("?",old_short,i)

			select
				when i=2 then suffix = "nd"
				when i=3 then suffix = "rd"
				otherwise
					suffix = "th"
			end
			desc = changestr("?",old_desc,i||suffix)

			Count = Count+1
			say mt short
			say desc
			say
			say comment
			say
		end
	end
end

call lineout "<STDERR>","Total MTs=" Count
