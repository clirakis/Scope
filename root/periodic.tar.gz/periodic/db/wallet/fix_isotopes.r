/**
 Hydrogen	H 	 1
 Helium		He 	 2
 Lithium	Li 	 3
 Beryllium	Be 	 4
 Boron		B 	 5
 Carbon	 	C 	 6
 Nitrogen	N 	 7
 Oxygen	 	O 	 8
 Fluorine	F 	 9
 Neon	 	Ne 	10
 Sodium	 	Na 	11
 Magnesium	Mg 	12
 Aluminum	Al 	13
 Silicon	Si 	14
 Phosphorus	P 	15
 Sulfur	 	S 	16
 Chlorine	Cl 	17
 Argon	 	Ar 	18
 Potassium	K 	19
 Calcium	Ca 	20
 Scandium	Sc 	21
 Titanium	Ti 	22
 Vanadium	V 	23
 Chromium	Cr 	24
 Manganese	Mn 	25
 Iron	 	Fe 	26
 Cobalt	 	Co 	27
 Nickel	 	Ni 	28
 Copper	 	Cu 	29
 Zinc	 	Zn 	30
 Gallium	Ga 	31
 Germanium	Ge 	32
 Arsenic	As 	33
 Selenium	Se 	34
 Bromine	Br 	35
 Krypton	Kr 	36
 Rubidium	Rb 	37
 Strontium	Sr 	38
 Yttrium	Y 	39
 Zirconium	Zr 	40
 Niobium	Nb 	41
 Molybdenum	Mo 	42
 Technetium	Tc 	43
 Ruthenium	Ru 	44
 Rhodium	Rh 	45
 Palladium	Pd 	46
 Silver	 	Ag 	47
 Cadmium	Cd 	48
 Indium	 	In 	49
 Tin		Sn 	50
 Antimony	Sb 	51
 Tellurium	Te 	52
 Iodine	 	I 	53
 Xenon	 	Xe 	54
 Cesium	 	Cs 	55
 Barium	 	Ba 	56
 Lanthanum	La 	57
 Cerium	 	Ce 	58
 Praseodymium 	Pr 	59
 Neodymium	Nd 	60
 Promethium	Pm 	61
 Samarium	Sm 	62
 Europium	Eu 	63
 Gadolinium	Gd 	64
 Terbium	Tb 	65
 Dysprosium	Dy 	66
 Holmium	Ho 	67
 Erbium	 	Er 	68
 Thulium	Tm 	69
 Ytterbium	Yb 	70
 Lutetium	Lu 	71
 Hafnium	Hf 	72
 Tantalum	Ta 	73
 Tungsten	W 	74
 Rhenium	Re 	75
 Osmium	 	Os 	76
 Iridium	Ir 	77
 Platinum	Pt 	78
 Gold	 	Au 	79
 Mercury	Hg 	80
 Thallium	Tl 	81
 Lead	 	Pb 	82
 Bismuth	Bi 	83
 Polonium	Po 	84
 Astatine	At 	85
 Radon	 	Rn 	86
 Francium	Fr 	87
 Radium	 	Ra 	88
 Actinium	Ac 	89
 Thorium	Th 	90
 Protactinium 	Pa 	91
 Uranium	U 	92
 Neptunium	Np 	93
 Plutonium	Pu 	94
 Americium	Am 	95
 Curium	 	Cm 	96
 Berkelium	Bk 	97
 Californium	Cf 	98
 Einsteinium	Es 	99
 Fermium	Fm 	100
 Mendelevium	Md 	101
 Nobelium	No 	102
 Lawrencium	Lr 	103
 Rutherfordium 	Rf 	104
 Hahnium	Ha 	105
 Seaborgium	Sg 	106
 Nielsbohrium 	Ns 	107
 Hassium	Hs 	108
 Meitnerium	Mt 	109
 Ununnilium	Uun 	110
 Unununium	Uuu 	111
 Ununbium	Uub 	112
 Ununtrium	Uut 	113
 Ununquadium	Uuq 	114
 Ununpentium	Uup 	115
 Ununhexium	Uuh 	116
 Ununseptium	Uus 	117
 Ununoctium	Uuo 	118
*/
name. = ""
do n=2 until sourceline(n)="*/"
	line = sourceline(n)
	if line="*/" then leave
	parse var line name sym z
	z = z+0
	name.z = strip(name)
	symbol.z = strip(sym)
end
lastz = z

"cat app1.html (stack"

nl = "0A"x
space = "   "
info. = copies(space"-"nl,5)
do queued()
	parse pull line
	line = changestr("<TR>",line,"")
	line = changestr("<I>",line,"(")
	line = changestr("</I>",line,")")
	line = changestr("<SUP>",line," ")
	line = changestr("</SUP>",line,"")
	info = ""
	parse var line "<TD>" z "<TD>" name "<TD>" line
	do i=1 while line <> ""
		parse var line a "<TD>" line
		a = strip(a)
		if a = "" then a ="-"
		info = info || space || a || nl
	end
	if i<5 then info = info || copies(space"-"nl,6-i)
	z = z + 0
	info.z = info
end

"ls z*.html (stack"
fout = open("isotopes.dat","w")
call lineout fout,lastz
do queued()
	parse pull file
	call makebuf
	 "cat" file "(stack"
	/* skip until === */
	do queued('T')
		parse pull line
		if word(line,1) == "===" then leave
	end
	n = 0
	iso. = ""
	prev = " "
	do queued('T')
		parse pull line
		line = changestr("09"x,line,"        ")
		if left(line,1) ^= "" then leave
		if left(line,20) = "" then iterate
		parse var line zz +4 ss +4 info
		if datatype(zz) == "NUM" then do
			z = zz+0
			symbol = ss
		end
		info = changestr("<I>",info,"(")
		info = changestr("</I>",info,")")

		if pos("<B>",info) <> 0 then info = overlay("*",info,1)

		info = changestr("<B>",info,"")
		info = changestr("</B>",info,"")

		info = changestr("&gt;",info,">")
		info = changestr("&lt;",info,"<")

		info = changestr("()",info,"  ")


		meta = substr(info,5,1)
		lower meta
		if prev=="m" & meta = "m" then do
			meta = "n"
		end
		info = overlay(meta,info,5)
		prev = meta

		n = n+1
		iso.n = info
	end
	call dropbuf
	lower isotopes
	say z name.z
	if name.z <> "" then do
		call lineout fout,z symbol.z name.z n
		call write fout,info.z
		do i=1 to n
			call lineout fout,iso.i
		end
	end
end
do z=112 to 118
	call lineout fout,z symbol.z name.z 0
end
call close fout
exit
