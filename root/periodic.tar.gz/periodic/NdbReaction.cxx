#include "NdbReaction.h"

ClassImp(NdbReaction)
