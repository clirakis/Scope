#include "NdbMaterial.h"

ClassImp(NdbMaterial)
